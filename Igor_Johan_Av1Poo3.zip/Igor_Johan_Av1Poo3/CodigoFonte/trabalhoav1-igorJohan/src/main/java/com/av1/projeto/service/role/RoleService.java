package com.av1.projeto.service.role;

import com.av1.projeto.model.Role;
import java.util.List;

public interface RoleService {
    Role findByNome(String nome);
    Role salvar(Role role);
    List<Role> listarTodos();
}