package com.av1.projeto.controller;

import com.av1.projeto.model.Fornecedor;
import com.av1.projeto.service.fornecedor.FornecedorService;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class FornecedorController implements Serializable {

    @EJB
    private FornecedorService fornecedorService;

    private List<Fornecedor> fornecedores;
    private Fornecedor fornecedorSelecionado = new Fornecedor();

    @PostConstruct
    public void init() {
        carregarFornecedores();
    }

    private void carregarFornecedores() {
        fornecedores = fornecedorService.listarTodos();
    }

    public void novo() {
        fornecedorSelecionado = new Fornecedor();
    }

    public void prepararEdicao(Fornecedor fornecedor) {
        this.fornecedorSelecionado = fornecedor;
    }

    public void salvar() {
        fornecedorService.salvar(fornecedorSelecionado);
        novo();
        carregarFornecedores();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso!", "Fornecedor salvo."));
    }

    public void remover(Long id) {
        fornecedorService.remover(id);
        carregarFornecedores();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Fornecedor removido."));
    }

    // Getters e Setters
    public List<Fornecedor> getFornecedores() {
        return fornecedores;
    }

    public Fornecedor getFornecedorSelecionado() {
        return fornecedorSelecionado;
    }

    public void setFornecedorSelecionado(Fornecedor fornecedorSelecionado) {
        this.fornecedorSelecionado = fornecedorSelecionado;
    }
}