package com.av1.projeto.service.produto;

import com.av1.projeto.model.Produto;
import com.av1.projeto.service.audit.AuditLogService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class ProdutoServiceImpl implements ProdutoService {

    @PersistenceContext
    private EntityManager em;

    @EJB
    private AuditLogService auditLogService; // Injetando o serviço de auditoria

    @Override
    public Produto salvar(Produto produto) {
        // Para a auditoria, precisamos saber quem está fazendo a ação.
        // Como o serviço EJB não tem acesso direto à sessão HTTP, a melhor forma
        // seria passar o nome do usuário logado como parâmetro para o método.
        // Para simplificar aqui, usaremos um usuário "SISTEMA".
        // O ideal seria: public Produto salvar(Produto produto, String usuarioLogado)
        String usuarioExecutor = "SISTEMA"; // Simplificação. O ideal seria obter da sessão.

        if (produto.getId() == null) {
            em.persist(produto);
            auditLogService.logAction(usuarioExecutor, "CREATE_PRODUCT", "Produto criado: " + produto.getNome());
            return produto;
        } else {
            Produto merged = em.merge(produto);
            auditLogService.logAction(usuarioExecutor, "UPDATE_PRODUCT", "Produto atualizado: " + produto.getNome() + " (ID: " + produto.getId() + ")");
            return merged;
        }
    }

    @Override
    public List<Produto> listarTodos() {
        return em.createQuery("SELECT p FROM Produto p ORDER BY p.nome", Produto.class).getResultList();
    }

    @Override
    public void remover(Long id) {
        Produto produto = em.find(Produto.class, id);
        if (produto != null) {
            String usuarioExecutor = "SISTEMA"; // Simplificação
            auditLogService.logAction(usuarioExecutor, "DELETE_PRODUCT", "Produto removido: " + produto.getNome() + " (ID: " + id + ")");
            em.remove(produto);
        }
    }
}