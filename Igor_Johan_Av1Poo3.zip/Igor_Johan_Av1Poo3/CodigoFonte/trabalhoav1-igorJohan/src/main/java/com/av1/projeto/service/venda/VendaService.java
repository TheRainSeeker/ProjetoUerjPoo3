package com.av1.projeto.service.venda;

import com.av1.projeto.model.Venda;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public interface VendaService {
    Venda salvar(Venda venda);
    List<Venda> listarTodas();
    Map<LocalDate, BigDecimal> getVendasPorDia();
    Venda buscarPorIdComItens(Long id);
}