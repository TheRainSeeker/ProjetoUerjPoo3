package com.av1.projeto.service.compra;
import com.av1.projeto.model.Compra;
import java.util.List;

public interface CompraService {
    Compra salvar(Compra compra);
    List<Compra> listarTodas();
}