// EmailService.java

package com.av1.projeto.service;

import javax.ejb.Stateless;
import javax.faces.context.FacesContext;
import javax.servlet.http.HttpServletRequest;

@Stateless
public class EmailService {

    public void sendPasswordResetEmail(String email, String resetToken) {
        // Monta a URL base da aplicação dinamicamente
        HttpServletRequest req = (HttpServletRequest) FacesContext.getCurrentInstance().getExternalContext().getRequest();
        String baseUrl = req.getScheme() + "://" + req.getServerName() + ":" + req.getServerPort() + req.getContextPath();
        String resetUrl = baseUrl + "/resetPassword.xhtml?token=" + resetToken;

        System.out.println("----------------------------------------------");
        System.out.println("Simulando o envio de e-mail para: " + email);
        System.out.println("Para redefinir sua senha, acesse o link abaixo:");
        System.out.println(resetUrl);
        System.out.println("Seu token de recuperação de senha é: " + resetToken);
        System.out.println("----------------------------------------------");
    }
}