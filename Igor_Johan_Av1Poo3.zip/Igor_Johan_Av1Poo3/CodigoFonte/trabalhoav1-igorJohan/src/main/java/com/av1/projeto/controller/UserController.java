package com.av1.projeto.controller;

import com.av1.projeto.model.Role;
import com.av1.projeto.model.User;
import com.av1.projeto.service.role.RoleService;
import com.av1.projeto.service.user.UserService;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class UserController implements Serializable {

    @EJB
    private UserService userService;
    @EJB
    private RoleService roleService;

    private List<User> usuarios;
    private User usuarioSelecionado = new User();
    private List<Role> todosPerfis;

    private String emailRecuperacao;
    private String tokenRecuperacao;
    private String novaSenha;

    @PostConstruct
    public void init() {
        carregarUsuarios();
        todosPerfis = roleService.listarTodos();
    }

    private void carregarUsuarios() { usuarios = userService.listarTodos(); }

    public void novo() {
        usuarioSelecionado = new User();
    }

    public void prepararEdicao(User user) {

        // Busca uma instância fresca do usuário do banco para garantir que a coleção de 'roles'
        // seja carregada junto e possa ser modificada.
        this.usuarioSelecionado = userService.buscarPorId(user.getId());
    }

    public void salvar() {
        if (usuarioSelecionado.getId() != null && (usuarioSelecionado.getPassword() == null || usuarioSelecionado.getPassword().isEmpty())) {
            User usuarioExistente = userService.buscarPorId(usuarioSelecionado.getId());
            if (usuarioExistente != null) {
                usuarioSelecionado.setPassword(usuarioExistente.getPassword());
            }
        }
        userService.salvar(usuarioSelecionado);
        novo();
        carregarUsuarios();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso!", "Usuário salvo."));
    }

    public void remover(Long id) {
        userService.remover(id);
        carregarUsuarios();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Usuário removido."));
    }

    public void solicitarToken() {
        if (emailRecuperacao != null && !emailRecuperacao.isEmpty()) {
            userService.gerarTokenRecuperacaoSenha(emailRecuperacao);
        }
        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Solicitação Enviada", "Se um usuário com este e-mail existir em nossa base, um link para redefinição de senha será gerado no console do servidor."));
    }

    public String redefinirSenha() {
        boolean sucesso = userService.redefinirSenha(tokenRecuperacao, novaSenha);
        if (sucesso) {
            FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso!", "Senha redefinida. Faça o login com sua nova senha."));
            return "login.xhtml?faces-redirect=true";
        } else {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Token inválido ou expirado. Solicite um novo."));
            return null;
        }
    }

    // Getters e Setters
    public List<User> getUsuarios() { return usuarios; }
    public void setUsuarios(List<User> usuarios) { this.usuarios = usuarios; }
    public User getUsuarioSelecionado() { return usuarioSelecionado; }
    public void setUsuarioSelecionado(User usuarioSelecionado) { this.usuarioSelecionado = usuarioSelecionado; }
    public List<Role> getTodosPerfis() { return todosPerfis; }
    public String getEmailRecuperacao() { return emailRecuperacao; }
    public void setEmailRecuperacao(String emailRecuperacao) { this.emailRecuperacao = emailRecuperacao; }
    public String getTokenRecuperacao() { return tokenRecuperacao; }
    public void setTokenRecuperacao(String tokenRecuperacao) { this.tokenRecuperacao = tokenRecuperacao; }
    public String getNovaSenha() { return novaSenha; }
    public void setNovaSenha(String novaSenha) { this.novaSenha = novaSenha; }
}