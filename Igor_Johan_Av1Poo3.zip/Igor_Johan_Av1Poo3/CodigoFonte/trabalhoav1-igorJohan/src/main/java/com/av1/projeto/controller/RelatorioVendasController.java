package com.av1.projeto.controller;

import com.av1.projeto.model.Venda;
import com.av1.projeto.service.venda.VendaService;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class RelatorioVendasController implements Serializable {

    @EJB
    private VendaService vendaService;

    private List<Venda> vendas;

    @PostConstruct
    public void init() {
        carregarVendas();
    }

    private void carregarVendas() {
        vendas = vendaService.listarTodas();
    }

    // Getters
    public List<Venda> getVendas() {
        return vendas;
    }
}