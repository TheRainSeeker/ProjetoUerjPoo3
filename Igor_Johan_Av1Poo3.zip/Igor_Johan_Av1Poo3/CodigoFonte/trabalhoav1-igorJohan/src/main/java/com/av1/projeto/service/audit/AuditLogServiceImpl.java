package com.av1.projeto.service.audit;

import com.av1.projeto.model.AuditLog;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class AuditLogServiceImpl implements AuditLogService {

    @PersistenceContext
    private EntityManager em;

    @Override
    public void logAction(String username, String action, String details) {
        try {
            AuditLog log = new AuditLog();
            log.setUsername(username);
            log.setAction(action);
            log.setDetails(details);
            em.persist(log);
        } catch (Exception e) {
            // Em um sistema de produção, logar o erro em um arquivo de texto, por exemplo.
            // A falha na auditoria não deve quebrar a funcionalidade principal.
            System.err.println("Falha ao registrar log de auditoria: " + e.getMessage());
        }
    }

    @Override
    public List<AuditLog> listarTodos() {
        return em.createQuery("SELECT a FROM AuditLog a ORDER BY a.timestamp DESC", AuditLog.class)
                .getResultList();
    }
}