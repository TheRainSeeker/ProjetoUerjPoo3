package com.av1.projeto.service.fornecedor;

import com.av1.projeto.model.Fornecedor;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class FornecedorServiceImpl implements FornecedorService {

    @PersistenceContext
    private EntityManager em;

    @Override
    public Fornecedor salvar(Fornecedor fornecedor) {
        if (fornecedor.getId() == null) {
            em.persist(fornecedor);
            return fornecedor;
        } else {
            return em.merge(fornecedor);
        }
    }

    @Override
    public List<Fornecedor> listarTodos() {
        return em.createQuery("SELECT f FROM Fornecedor f ORDER BY f.nome", Fornecedor.class).getResultList();
    }

    @Override
    public void remover(Long id) {
        Fornecedor fornecedor = em.find(Fornecedor.class, id);
        if (fornecedor != null) {
            em.remove(fornecedor);
        }
    }
}