package com.av1.projeto.service.auth;

import com.av1.projeto.model.User;

public interface AuthService {
    User autenticar(String username, String password);
}