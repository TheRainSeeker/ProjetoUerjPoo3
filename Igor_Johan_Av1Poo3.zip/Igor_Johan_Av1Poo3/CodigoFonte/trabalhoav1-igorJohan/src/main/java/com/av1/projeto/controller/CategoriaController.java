package com.av1.projeto.controller;

import com.av1.projeto.model.Categoria;
import com.av1.projeto.service.categoria.CategoriaService;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class CategoriaController implements Serializable {

    @EJB
    private CategoriaService categoriaService;

    private List<Categoria> categorias;
    private Categoria categoriaSelecionada = new Categoria();

    @PostConstruct
    public void init() {
        carregarCategorias();
    }

    private void carregarCategorias() {
        categorias = categoriaService.listarTodos();
    }

    public void novo() {
        categoriaSelecionada = new Categoria();
    }

    public void prepararEdicao(Categoria categoria) {
        this.categoriaSelecionada = categoria;
    }

    public void salvar() {
        categoriaService.salvar(categoriaSelecionada);
        novo();
        carregarCategorias();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso!", "Categoria salva."));
    }

    public void remover(Long id) {
        categoriaService.remover(id);
        carregarCategorias();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Categoria removida."));
    }

    // Getters e Setters
    public List<Categoria> getCategorias() {
        return categorias;
    }

    public Categoria getCategoriaSelecionada() {
        return categoriaSelecionada;
    }

    public void setCategoriaSelecionada(Categoria categoriaSelecionada) {
        this.categoriaSelecionada = categoriaSelecionada;
    }
}