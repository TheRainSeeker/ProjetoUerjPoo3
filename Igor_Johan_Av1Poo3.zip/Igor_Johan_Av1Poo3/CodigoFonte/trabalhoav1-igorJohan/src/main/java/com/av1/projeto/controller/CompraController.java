package com.av1.projeto.controller;

import com.av1.projeto.model.*;
import com.av1.projeto.service.compra.CompraService;
import com.av1.projeto.service.fornecedor.FornecedorService;
import com.av1.projeto.service.produto.ProdutoService;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Named
@ViewScoped
public class CompraController implements Serializable {

    @EJB
    private CompraService compraService;
    @EJB
    private ProdutoService produtoService;
    @EJB
    private FornecedorService fornecedorService;

    private List<Produto> produtosDisponiveis;
    private List<Fornecedor> fornecedores;
    private List<ItemCompra> carrinhoDeCompra = new ArrayList<>();

    private Fornecedor fornecedorSelecionado;
    private BigDecimal valorTotalCompra = BigDecimal.ZERO;

    @PostConstruct
    public void init() {
        produtosDisponiveis = produtoService.listarTodos();
        fornecedores = fornecedorService.listarTodos();
    }

    public void adicionarAoCarrinho(Produto produto) {
        for (ItemCompra item : carrinhoDeCompra) {
            if (item.getProduto().equals(produto)) {
                item.setQuantidade(item.getQuantidade() + 1);
                recalcularTotal();
                return;
            }
        }
        ItemCompra novoItem = new ItemCompra();
        novoItem.setProduto(produto);
        novoItem.setQuantidade(1);
        novoItem.setCustoUnitario(produto.getPreco()); // Simplificação: usando preço de venda como custo
        carrinhoDeCompra.add(novoItem);
        recalcularTotal();
    }

    public void recalcularTotal() {
        valorTotalCompra = BigDecimal.ZERO;
        for (ItemCompra item : carrinhoDeCompra) {
            BigDecimal subtotal = item.getCustoUnitario().multiply(new BigDecimal(item.getQuantidade()));
            valorTotalCompra = valorTotalCompra.add(subtotal);
        }
    }

    public void registrarCompra() {
        if (carrinhoDeCompra.isEmpty() || fornecedorSelecionado == null) {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_WARN, "Atenção!", "Selecione um fornecedor e adicione produtos."));
            return;
        }

        Compra novaCompra = new Compra();
        novaCompra.setFornecedor(fornecedorSelecionado);
        novaCompra.setItens(new ArrayList<>(carrinhoDeCompra));
        novaCompra.setValorTotal(valorTotalCompra);

        compraService.salvar(novaCompra);

        carrinhoDeCompra.clear();
        recalcularTotal();
        produtosDisponiveis = produtoService.listarTodos(); // Recarrega produtos para ver estoque atualizado

        FacesContext.getCurrentInstance().addMessage(null,
                new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso!", "Compra registrada e estoque atualizado."));
    }

    // Getters e Setters
    public List<Produto> getProdutosDisponiveis() { return produtosDisponiveis; }
    public List<Fornecedor> getFornecedores() { return fornecedores; }
    public List<ItemCompra> getCarrinhoDeCompra() { return carrinhoDeCompra; }
    public Fornecedor getFornecedorSelecionado() { return fornecedorSelecionado; }
    public void setFornecedorSelecionado(Fornecedor fornecedorSelecionado) { this.fornecedorSelecionado = fornecedorSelecionado; }
    public BigDecimal getValorTotalCompra() { return valorTotalCompra; }
}