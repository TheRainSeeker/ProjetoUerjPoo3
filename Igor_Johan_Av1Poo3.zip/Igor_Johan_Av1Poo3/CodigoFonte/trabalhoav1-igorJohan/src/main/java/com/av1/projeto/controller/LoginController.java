package com.av1.projeto.controller;

import com.av1.projeto.model.User;
import com.av1.projeto.service.audit.AuditLogService;
import com.av1.projeto.service.auth.AuthService;

import javax.ejb.EJB;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import java.io.IOException;
import java.io.Serializable;

@Named
@SessionScoped
public class LoginController implements Serializable {

    @EJB
    private AuthService authService;

    @EJB // Garanta a injeção do serviço de log
    private AuditLogService auditLogService;

    private String username;
    private String password;
    private User usuarioLogado;

    public String login() {
        usuarioLogado = authService.autenticar(username, password);

        if (usuarioLogado != null) {
            FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("usuarioLogado", usuarioLogado);
            return "/vendas.xhtml?faces-redirect=true";
        } else {
            FacesContext.getCurrentInstance().addMessage(null,
                    new FacesMessage(FacesMessage.SEVERITY_ERROR, "Login falhou!", "Usuário ou senha inválidos."));
            return null;
        }
    }

    public void logout() throws IOException {
        if (isLogado()) {
            // LOG DE AUDITORIA
            auditLogService.logAction(usuarioLogado.getUsername(), "LOGOUT", "Usuário encerrou a sessão.");
        }
        FacesContext.getCurrentInstance().getExternalContext().invalidateSession();
        FacesContext.getCurrentInstance().getExternalContext().redirect("login.xhtml");
    }

    public boolean isLogado() {
        return usuarioLogado != null;
    }

    // Getters e Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public User getUsuarioLogado() { return usuarioLogado; }
}