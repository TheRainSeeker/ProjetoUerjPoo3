package com.av1.projeto.controller;

import com.av1.projeto.model.Role;
import com.av1.projeto.model.User;
import com.av1.projeto.service.audit.AuditLogService; // IMPORT
import com.av1.projeto.service.role.RoleService;
import com.av1.projeto.service.user.UserService;

import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;

@Named
@ViewScoped
public class RegistroController implements Serializable {

    @EJB
    private UserService userService;
    @EJB
    private RoleService roleService;
    @EJB // INJEÇÃO DO SERVIÇO DE LOG
    private AuditLogService auditLogService;

    private User novoUsuario = new User();

    public String registrar() {
        if (userService.buscarPorUsername(novoUsuario.getUsername()) != null) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "Nome de usuário já existe."));
            return null;
        }
        if (userService.buscarPorEmail(novoUsuario.getEmail()) != null) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, "Erro", "E-mail já cadastrado."));
            return null;
        }

        Role roleCliente = roleService.findByNome("CLIENTE");
        novoUsuario.getRoles().add(roleCliente);

        User usuarioSalvo = userService.salvar(novoUsuario);

        // LOG DE AUDITORIA
        auditLogService.logAction(usuarioSalvo.getUsername(), "CLIENT_REGISTER", "Novo cliente se registrou com ID: " + usuarioSalvo.getId());

        FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Sucesso!", "Sua conta foi criada. Faça o login."));

        return "login.xhtml?faces-redirect=true";
    }

    // Getter e Setter
    public User getNovoUsuario() { return novoUsuario; }
    public void setNovoUsuario(User novoUsuario) { this.novoUsuario = novoUsuario; }
}