package com.av1.projeto.service.venda;

import com.av1.projeto.model.ItemVenda;
import com.av1.projeto.model.Produto;
import com.av1.projeto.model.Venda;
import com.av1.projeto.service.audit.AuditLogService; // IMPORT
import javax.ejb.EJB; // IMPORT
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Tuple;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Stateless
public class VendaServiceImpl implements VendaService {

    @PersistenceContext
    private EntityManager em;

    @EJB // INJEÇÃO DO SERVIÇO DE LOG
    private AuditLogService auditLogService;

    @Override
    public Venda salvar(Venda venda) {
        for (ItemVenda item : venda.getItens()) {
            item.setVenda(venda);
            Produto produto = em.find(Produto.class, item.getProduto().getId());
            int novaQuantidade = produto.getQuantidadeEstoque() - item.getQuantidade();
            produto.setQuantidadeEstoque(novaQuantidade);
            em.merge(produto);
        }
        em.persist(venda);

        // LOG DE AUDITORIA
        String clienteUsername = (venda.getCliente() != null) ? venda.getCliente().getUsername() : "ANÔNIMO";
        auditLogService.logAction(clienteUsername, "CREATE_SALE", "Venda #" + venda.getId() + " finalizada. Valor: R$ " + venda.getValorTotal());

        return venda;
    }

    @Override
    public List<Venda> listarTodas() {
        return em.createQuery("SELECT DISTINCT v FROM Venda v LEFT JOIN FETCH v.itens i LEFT JOIN FETCH i.produto ORDER BY v.dataVenda DESC", Venda.class)
                .getResultList();
    }

    @Override
    public Map<LocalDate, BigDecimal> getVendasPorDia() {
        String jpql = "SELECT FUNCTION('DATE', v.dataVenda) as dia, SUM(v.valorTotal) as total " +
                "FROM Venda v GROUP BY FUNCTION('DATE', v.dataVenda) ORDER BY dia ASC";
        List<Tuple> results = em.createQuery(jpql, Tuple.class).getResultList();
        return results.stream()
                .collect(Collectors.toMap(
                        tuple -> ((Date) tuple.get("dia")).toLocalDate(),
                        tuple -> (BigDecimal) tuple.get("total"),
                        (oldValue, newValue) -> newValue,
                        LinkedHashMap::new
                ));
    }

    @Override
    public Venda buscarPorIdComItens(Long id) {
        try {
            return em.createQuery("SELECT v FROM Venda v LEFT JOIN FETCH v.itens i LEFT JOIN FETCH i.produto WHERE v.id = :id", Venda.class)
                    .setParameter("id", id)
                    .getSingleResult();
        } catch (Exception e) {
            return null;
        }
    }
}