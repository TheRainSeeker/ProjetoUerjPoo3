package com.av1.projeto.service.user;

import com.av1.projeto.model.User;
import java.util.List;

public interface UserService {
    User salvar(User user);
    List<User> listarTodos();
    User buscarPorId(Long id);
    void remover(Long id);
    User buscarPorEmail(String email);
    User buscarPorUsername(String username);
    List<User> listarClientes();
    void gerarTokenRecuperacaoSenha(String email);
    boolean redefinirSenha(String token, String novaSenha);
}