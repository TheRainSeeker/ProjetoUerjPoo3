package com.av1.projeto.service;

import com.av1.projeto.model.*;
import com.av1.projeto.service.categoria.CategoriaService;
import com.av1.projeto.service.fornecedor.FornecedorService;
import com.av1.projeto.service.produto.ProdutoService;
import com.av1.projeto.service.role.RoleService;
import com.av1.projeto.service.user.UserService;
import com.av1.projeto.service.venda.VendaService;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Singleton
@Startup
public class DataInitializer {

    @EJB private UserService userService;
    @EJB private RoleService roleService;
    @EJB private FornecedorService fornecedorService;
    @EJB private ProdutoService produtoService;
    @EJB private VendaService vendaService;
    @EJB private CategoriaService categoriaService;

    @PostConstruct
    public void init() {
        System.out.println("[DataInitializer] Iniciando a verificação de dados iniciais...");

        if (userService.listarTodos().isEmpty()) {
            System.out.println("[DataInitializer] Banco de dados vazio. Populando todos os dados de exemplo...");

            Role adminRole = createRole("ADMINISTRADOR");
            Role funcRole = createRole("FUNCIONARIO");
            Role clienteRole = createRole("CLIENTE");

            createUsers(adminRole, funcRole, clienteRole);
            createFornecedores();
            createCategorias();
            createProdutos();
            createVendas();
        } else {
            System.out.println("[DataInitializer] Banco de dados já populado. Nenhuma ação necessária.");
        }

        System.out.println("[DataInitializer] Verificação de dados iniciais concluída.");
    }

    private Role createRole(String roleName) {
        System.out.println("[DataInitializer] Criando perfil: " + roleName);
        Role role = new Role();
        role.setNome(roleName);
        return roleService.salvar(role);
    }

    private void createUsers(Role adminRole, Role funcRole, Role clienteRole) {
        System.out.println("[DataInitializer] Criando usuários padrão...");

        User adminUser = new User();
        adminUser.setUsername("admin");
        adminUser.setEmail("admin@admin.com");
        adminUser.setPassword("admin");
        adminUser.getRoles().add(adminRole);
        userService.salvar(adminUser);

        User funcUser = new User();
        funcUser.setUsername("func");
        funcUser.setEmail("func@func.com");
        funcUser.setPassword("func");
        funcUser.getRoles().add(funcRole);
        userService.salvar(funcUser);

        User clienteUser = new User();
        clienteUser.setUsername("cliente");
        clienteUser.setEmail("cliente@cliente.com");
        clienteUser.setPassword("cliente");
        clienteUser.getRoles().add(clienteRole);
        userService.salvar(clienteUser);
    }

    private void createFornecedores() {
        System.out.println("[DataInitializer] Criando fornecedores de exemplo...");
        Fornecedor f1 = new Fornecedor();
        f1.setNome("Distribuidora de Eletrônicos Tech");
        f1.setCnpj("11.222.333/0001-44");
        f1.setEmail("contato@techdist.com");
        fornecedorService.salvar(f1);

        Fornecedor f2 = new Fornecedor();
        f2.setNome("Importados de Qualidade LTDA");
        f2.setCnpj("55.666.777/0001-88");
        f2.setEmail("vendas@importados.com");
        fornecedorService.salvar(f2);
    }

    private void createCategorias() {
        System.out.println("[DataInitializer] Criando categorias de exemplo...");
        Categoria c1 = new Categoria();
        c1.setNome("Periféricos");
        categoriaService.salvar(c1);

        Categoria c2 = new Categoria();
        c2.setNome("Monitores");
        categoriaService.salvar(c2);
    }

    private void createProdutos() {
        System.out.println("[DataInitializer] Criando produtos de exemplo...");
        Fornecedor fornecedor = fornecedorService.listarTodos().get(0);
        List<Categoria> categorias = categoriaService.listarTodos();
        Categoria catPerifericos = categorias.stream().filter(c -> c.getNome().equals("Periféricos")).findFirst().orElse(null);
        Categoria catMonitores = categorias.stream().filter(c -> c.getNome().equals("Monitores")).findFirst().orElse(null);

        Produto p1 = new Produto();
        p1.setNome("Mouse Gamer RGB");
        p1.setPreco(new BigDecimal("150.75"));
        p1.setQuantidadeEstoque(50);
        p1.setFornecedor(fornecedor);
        p1.setCategoria(catPerifericos);
        produtoService.salvar(p1);

        Produto p2 = new Produto();
        p2.setNome("Teclado Mecânico");
        p2.setPreco(new BigDecimal("350.00"));
        p2.setQuantidadeEstoque(30);
        p2.setFornecedor(fornecedor);
        p2.setCategoria(catPerifericos);
        produtoService.salvar(p2);

        Produto p3 = new Produto();
        p3.setNome("Monitor 24 polegadas");
        p3.setPreco(new BigDecimal("1200.50"));
        p3.setQuantidadeEstoque(20);
        p3.setFornecedor(fornecedor);
        p3.setCategoria(catMonitores);
        produtoService.salvar(p3);
    }

    private void createVendas() {
        System.out.println("[DataInitializer] Criando vendas de exemplo...");
        List<Produto> produtos = produtoService.listarTodos();
        Produto produto1 = produtos.get(0);
        Produto produto2 = produtos.get(1);

        Venda venda1 = new Venda();
        ItemVenda item1Venda1 = new ItemVenda();
        item1Venda1.setProduto(produto1);
        item1Venda1.setQuantidade(2);
        item1Venda1.setPrecoUnitario(produto1.getPreco());
        venda1.getItens().add(item1Venda1);
        venda1.setValorTotal(produto1.getPreco().multiply(new BigDecimal(2)));
        venda1.setFormaPagamento("Cartão de Crédito");
        vendaService.salvar(venda1);

        Venda venda2 = new Venda();
        ItemVenda item1Venda2 = new ItemVenda();
        item1Venda2.setProduto(produto2);
        item1Venda2.setQuantidade(1);
        item1Venda2.setPrecoUnitario(produto2.getPreco());
        venda2.getItens().add(item1Venda2);
        venda2.setValorTotal(produto2.getPreco());
        venda2.setDataVenda(LocalDateTime.now().minusDays(1));
        venda2.setFormaPagamento("PIX");
        vendaService.salvar(venda2);
    }
}