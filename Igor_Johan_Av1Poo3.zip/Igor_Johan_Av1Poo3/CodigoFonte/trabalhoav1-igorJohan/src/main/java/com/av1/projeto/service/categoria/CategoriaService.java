package com.av1.projeto.service.categoria;

import com.av1.projeto.model.Categoria;
import java.util.List;

public interface CategoriaService {
    Categoria salvar(Categoria categoria);
    List<Categoria> listarTodos();
    void remover(Long id);
}