package com.av1.projeto.service.audit;

import com.av1.projeto.model.AuditLog;
import java.util.List;

public interface AuditLogService {
    void logAction(String username, String action, String details);
    List<AuditLog> listarTodos();
}