package com.av1.projeto.controller;

import com.av1.projeto.model.Categoria;
import com.av1.projeto.model.Fornecedor;
import com.av1.projeto.model.Produto;
import com.av1.projeto.service.categoria.CategoriaService;
import com.av1.projeto.service.fornecedor.FornecedorService;
import com.av1.projeto.service.produto.ProdutoService;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Named;
import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class ProdutoController implements Serializable {

    @EJB
    private ProdutoService produtoService;
    @EJB
    private FornecedorService fornecedorService;
    @EJB
    private CategoriaService categoriaService;

    private List<Produto> produtos;
    private List<Fornecedor> fornecedores;
    private List<Categoria> categorias;
    private Produto produtoSelecionado = new Produto();

    @PostConstruct
    public void init() {
        carregarProdutos();
        carregarFornecedores();
        carregarCategorias();
    }

    private void carregarProdutos() { produtos = produtoService.listarTodos(); }
    private void carregarFornecedores() { fornecedores = fornecedorService.listarTodos(); }
    private void carregarCategorias() { categorias = categoriaService.listarTodos(); }

    public void novo() { produtoSelecionado = new Produto(); }
    public void prepararEdicao(Produto produto) { this.produtoSelecionado = produto; }

    public void salvar() {
        produtoService.salvar(produtoSelecionado);
        novo();
        carregarProdutos();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage("Sucesso!", "Produto salvo."));
    }

    public void remover(Long id) {
        produtoService.remover(id);
        carregarProdutos();
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Aviso", "Produto removido."));
    }

    public String getEstiloEstoque(Produto produto) {
        if (produto.getQuantidadeEstoque() <= 5) {
            return "color: red; font-weight: bold;";
        }
        return "";
    }

    // Getters e Setters
    public List<Produto> getProdutos() { return produtos; }
    public void setProdutos(List<Produto> produtos) { this.produtos = produtos; }
    public List<Fornecedor> getFornecedores() { return fornecedores; }
    public void setFornecedores(List<Fornecedor> fornecedores) { this.fornecedores = fornecedores; }
    public Produto getProdutoSelecionado() { return produtoSelecionado; }
    public void setProdutoSelecionado(Produto produtoSelecionado) { this.produtoSelecionado = produtoSelecionado; }
    public List<Categoria> getCategorias() { return categorias; }
}