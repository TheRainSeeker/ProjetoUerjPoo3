package com.av1.projeto.service.auth;

import com.av1.projeto.model.User;
import com.av1.projeto.service.audit.AuditLogService; // Garanta que o import está aqui
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;

@Stateless
public class AuthServiceImpl implements AuthService {

    @PersistenceContext
    private EntityManager em;

    @EJB
    private AuditLogService auditLogService;

    @Override
    public User autenticar(String username, String password) {
        try {
            User user = em.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class)
                    .setParameter("username", username)
                    .getSingleResult();

            if (user != null && user.getPassword().equals(password)) {
                auditLogService.logAction(username, "LOGIN_SUCCESS", "Usuário autenticado com sucesso.");
                return user;
            } else {
                auditLogService.logAction(username, "LOGIN_FAILED", "Tentativa de login com senha incorreta.");
            }
        } catch (NoResultException e) {
            // LOG ADICIONADO AQUI
            auditLogService.logAction(username, "LOGIN_FAILED", "Tentativa de login com usuário inexistente.");
            return null;
        }
        return null;
    }
}