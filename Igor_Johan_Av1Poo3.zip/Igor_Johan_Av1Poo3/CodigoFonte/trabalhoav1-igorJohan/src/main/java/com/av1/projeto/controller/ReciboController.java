package com.av1.projeto.controller;

import com.av1.projeto.model.ItemVenda;
import com.av1.projeto.model.Venda;
import com.av1.projeto.service.venda.VendaService;
import org.primefaces.model.DefaultStreamedContent;
import org.primefaces.model.StreamedContent;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.inject.Named;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.Serializable;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.format.DateTimeFormatter;

@Named
@RequestScoped
public class ReciboController implements Serializable {

    @EJB
    private VendaService vendaService;

    private Venda venda;

    public void init() {
        String vendaIdParam = FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get("vendaId");
        if (vendaIdParam != null && !vendaIdParam.isEmpty()) {
            try {
                Long vendaId = Long.parseLong(vendaIdParam);
                this.venda = vendaService.buscarPorIdComItens(vendaId);
            } catch (NumberFormatException e) {
                // Tratar erro se o ID não for um número válido
                System.err.println("ID da venda inválido: " + vendaIdParam);
            }
        }
    }

    public StreamedContent getArquivoTxt() {
        if (venda == null) {
            init(); // Garante que a venda seja carregada se ainda não foi
            if (venda == null) return null;
        }


        StringBuilder sb = new StringBuilder();
        sb.append("--- RECIBO DE VENDA ---\r\n");
        sb.append("ID da Venda: ").append(venda.getId()).append("\r\n");
        sb.append("Data: ").append(venda.getDataVenda().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"))).append("\r\n");
        if (venda.getCliente() != null) {
            sb.append("Cliente: ").append(venda.getCliente().getUsername()).append("\r\n");
        }
        sb.append("Forma de Pagamento: ").append(venda.getFormaPagamento()).append("\r\n\r\n");
        sb.append("--- ITENS ---\r\n");
        for (ItemVenda item : venda.getItens()) {
            sb.append(String.format("%-20s | Qtd: %-5d | Vlr. Un: R$ %-10.2f | Subtotal: R$ %-10.2f\r\n",
                    item.getProduto().getNome(),
                    item.getQuantidade(),
                    item.getPrecoUnitario(),
                    item.getPrecoUnitario().multiply(new BigDecimal(item.getQuantidade()))
            ));
        }
        sb.append("\r\n--- TOTAL ---\r\n");
        sb.append(String.format("Valor Total: R$ %.2f\r\n", venda.getValorTotal()));
        sb.append("-----------------------\r\n");

        InputStream stream = new ByteArrayInputStream(sb.toString().getBytes(StandardCharsets.UTF_8));
        return DefaultStreamedContent.builder()
                .name("recibo-" + venda.getId() + ".txt")
                .contentType("text/plain")
                .stream(() -> stream)
                .build();
    }

    public Venda getVenda() {
        if (venda == null) {
            init();
        }
        return venda;
    }
}