package com.av1.projeto.security;

import com.av1.projeto.model.Role;
import com.av1.projeto.model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

@WebFilter("/*")
public class AuthorizationFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        String requestedURI = req.getRequestURI();
        String contextPath = req.getContextPath();

        boolean isPublicResource = requestedURI.equals(contextPath + "/login.xhtml") ||
                requestedURI.equals(contextPath + "/registro.xhtml") ||
                requestedURI.equals(contextPath + "/forgotPassword.xhtml") ||
                requestedURI.equals(contextPath + "/resetPassword.xhtml") ||
                requestedURI.equals(contextPath + "/acesso-negado.xhtml") ||
                requestedURI.startsWith(contextPath + "/javax.faces.resource");

        if (isPublicResource) {
            chain.doFilter(request, response);
            return;
        }

        User usuarioLogado = (session != null) ? (User) session.getAttribute("usuarioLogado") : null;

        if (usuarioLogado == null) {
            res.sendRedirect(contextPath + "/login.xhtml");
        } else {
            boolean isCliente = hasRole(usuarioLogado.getRoles(), "CLIENTE");
            boolean isAdmin = hasRole(usuarioLogado.getRoles(), "ADMINISTRADOR");

            // Lista de páginas que NÃO são para clientes
            List<String> paginasRestritasParaCliente = Arrays.asList(
                    "/usuarios.xhtml", "/produtos.xhtml", "/categorias.xhtml",
                    "/fornecedores.xhtml", "/compras.xhtml", "/relatorios.xhtml"
            );

            boolean tentandoAcessarPaginaRestrita = paginasRestritasParaCliente.stream().anyMatch(requestedURI::contains);

            // REGRA 1: Se for cliente, barra o acesso a páginas administrativas.
            if (isCliente && tentandoAcessarPaginaRestrita) {
                res.sendRedirect(contextPath + "/acesso-negado.xhtml");
                return;
            }

            // REGRA 2: Se não for admin, barra o acesso à página de usuários.
            if (requestedURI.contains("/usuarios.xhtml") && !isAdmin) {
                res.sendRedirect(contextPath + "/acesso-negado.xhtml");
                return;
            }

            // Se passou por todas as regras, permite o acesso.
            chain.doFilter(request, response);
        }
    }

    private boolean hasRole(Set<Role> roles, String roleName) {
        if (roles == null) return false;
        return roles.stream().anyMatch(role -> role.getNome().equals(roleName));
    }

    @Override
    public void init(FilterConfig filterConfig) {}

    @Override
    public void destroy() {}
}