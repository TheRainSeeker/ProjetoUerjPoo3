package com.av1.projeto.service.compra;

import com.av1.projeto.model.Compra;
import com.av1.projeto.model.ItemCompra;
import com.av1.projeto.model.Produto;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class CompraServiceImpl implements CompraService {

    @PersistenceContext
    private EntityManager em;

    @Override
    public Compra salvar(Compra compra) {
        for (ItemCompra item : compra.getItens()) {
            item.setCompra(compra);

            // Lógica para adicionar ao estoque
            Produto produto = em.find(Produto.class, item.getProduto().getId());
            int novaQuantidade = produto.getQuantidadeEstoque() + item.getQuantidade();
            produto.setQuantidadeEstoque(novaQuantidade);
            em.merge(produto);
        }
        em.persist(compra);
        return compra;
    }

    @Override
    public List<Compra> listarTodas() {
        return em.createQuery("SELECT DISTINCT c FROM Compra c LEFT JOIN FETCH c.itens ORDER BY c.dataCompra DESC", Compra.class)
                .getResultList();
    }
}