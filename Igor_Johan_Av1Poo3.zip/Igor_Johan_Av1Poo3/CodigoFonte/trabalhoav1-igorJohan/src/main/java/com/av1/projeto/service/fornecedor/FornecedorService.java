package com.av1.projeto.service.fornecedor;

import com.av1.projeto.model.Fornecedor;
import java.util.List;

public interface FornecedorService {
    Fornecedor salvar(Fornecedor fornecedor);
    List<Fornecedor> listarTodos();
    void remover(Long id);
}