package com.av1.projeto.service.user;

import com.av1.projeto.model.Role;
import com.av1.projeto.model.User;
import com.av1.projeto.service.EmailService;
import com.av1.projeto.service.role.RoleService;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Stateless
public class UserServiceImpl implements UserService {

    @PersistenceContext
    private EntityManager em;

    @EJB
    private RoleService roleService;

    @EJB
    private EmailService emailService;

    @Override
    public User salvar(User user) {
        if (user.getId() == null) {
            em.persist(user);
            return user;
        } else {
            return em.merge(user);
        }
    }

    @Override
    public List<User> listarTodos() {
        return em.createQuery("SELECT u FROM User u", User.class).getResultList();
    }

    @Override
    public User buscarPorId(Long id) {

        try {
            return em.createQuery("SELECT u FROM User u LEFT JOIN FETCH u.roles WHERE u.id = :id", User.class)
                    .setParameter("id", id)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public void remover(Long id) {
        User user = buscarPorId(id);
        if (user != null) {
            em.remove(em.merge(user));
        }
    }

    @Override
    public User buscarPorEmail(String email) {
        try {
            return em.createQuery("SELECT u FROM User u WHERE u.email = :email", User.class)
                    .setParameter("email", email)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public User buscarPorUsername(String username) {
        try {
            return em.createQuery("SELECT u FROM User u WHERE u.username = :username", User.class)
                    .setParameter("username", username)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public List<User> listarClientes() {
        return em.createQuery("SELECT u FROM User u JOIN u.roles r WHERE r.nome = 'CLIENTE' ORDER BY u.username", User.class)
                .getResultList();
    }

    @Override
    public void gerarTokenRecuperacaoSenha(String email) {
        User user = buscarPorEmail(email);
        if (user != null) {
            String token = UUID.randomUUID().toString();
            LocalDateTime expiryDate = LocalDateTime.now().plusMinutes(30);
            user.setResetToken(token);
            user.setTokenExpiryDate(expiryDate);
            em.merge(user); // Usar merge em vez de salvar para garantir o gerenciamento
            emailService.sendPasswordResetEmail(user.getEmail(), token);
        }
    }

    @Override
    public boolean redefinirSenha(String token, String novaSenha) {
        try {
            User user = em.createQuery("SELECT u FROM User u WHERE u.resetToken = :token AND u.tokenExpiryDate > :now", User.class)
                    .setParameter("token", token)
                    .setParameter("now", LocalDateTime.now())
                    .getSingleResult();
            user.setPassword(novaSenha);
            user.setResetToken(null);
            user.setTokenExpiryDate(null);
            em.merge(user); // Usar merge
            return true;
        } catch (NoResultException e) {
            return false;
        }
    }
}