package com.av1.projeto.controller;

import com.av1.projeto.model.ItemVenda;
import com.av1.projeto.model.Produto;
import com.av1.projeto.model.User;
import com.av1.projeto.model.Venda;
import com.av1.projeto.service.produto.ProdutoService;
import com.av1.projeto.service.user.UserService;
import com.av1.projeto.service.venda.VendaService;
import org.primefaces.model.chart.Axis;
import org.primefaces.model.chart.AxisType;
import org.primefaces.model.chart.BarChartModel;
import org.primefaces.model.chart.ChartSeries;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.view.ViewScoped;
import javax.inject.Inject; // IMPORT NOVO
import javax.inject.Named;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Named
@ViewScoped
public class VendaController implements Serializable {

    @EJB
    private ProdutoService produtoService;
    @EJB
    private VendaService vendaService;
    @EJB
    private UserService userService;

    @Inject // INJEÇÃO DO LOGINCONTROLLER PARA SABER QUEM ESTÁ LOGADO
    private LoginController loginController;

    private List<Produto> produtosDisponiveis;
    private List<ItemVenda> carrinho = new ArrayList<>();
    private BigDecimal valorTotalCarrinho = BigDecimal.ZERO;
    private BarChartModel barModel;

    private List<User> clientes;
    private User clienteSelecionado;
    private String formaPagamentoSelecionada = "Cartão de Crédito";

    @PostConstruct
    public void init() {
        produtosDisponiveis = produtoService.listarTodos();
        clientes = userService.listarClientes();
        createBarModel();
    }

    public void createBarModel() {
        barModel = new BarChartModel();
        ChartSeries series = new ChartSeries();
        series.setLabel("Vendas");
        Map<LocalDate, BigDecimal> vendasPorDia = vendaService.getVendasPorDia();
        if (vendasPorDia == null || vendasPorDia.isEmpty()) {
            series.set("Nenhuma venda", 0);
        } else {
            vendasPorDia.forEach((data, total) -> series.set(data.format(DateTimeFormatter.ofPattern("dd/MM")), total));
        }
        barModel.addSeries(series);
        barModel.setTitle("Vendas por Dia");
        barModel.setLegendPosition("ne");
        Axis xAxis = barModel.getAxis(AxisType.X);
        xAxis.setLabel("Data");
        Axis yAxis = barModel.getAxis(AxisType.Y);
        yAxis.setLabel("Valor (R$)");
        yAxis.setMin(0);
    }

    public void adicionarAoCarrinho(Produto produto) {
        for (ItemVenda item : carrinho) {
            if (item.getProduto().equals(produto)) {
                item.setQuantidade(item.getQuantidade() + 1);
                recalcularTotal();
                return;
            }
        }
        ItemVenda novoItem = new ItemVenda();
        novoItem.setProduto(produto);
        novoItem.setQuantidade(1);
        novoItem.setPrecoUnitario(produto.getPreco());
        carrinho.add(novoItem);
        recalcularTotal();
    }

    public void recalcularTotal() {
        valorTotalCarrinho = BigDecimal.ZERO;
        for (ItemVenda item : carrinho) {
            BigDecimal subtotal = item.getPrecoUnitario().multiply(new BigDecimal(item.getQuantidade()));
            valorTotalCarrinho = valorTotalCarrinho.add(subtotal);
        }
    }

    public String finalizarVenda() {
        if (carrinho.isEmpty()) {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, "Carrinho vazio!", "Adicione produtos antes de finalizar."));
            return null;
        }
        Venda novaVenda = new Venda();
        novaVenda.setItens(new ArrayList<>(carrinho));
        novaVenda.setValorTotal(valorTotalCarrinho);
        novaVenda.setFormaPagamento(formaPagamentoSelecionada);

        // --- LÓGICA DE CLIENTE APRIMORADA ---
        User usuarioLogado = loginController.getUsuarioLogado();
        boolean isCliente = usuarioLogado.getRoles().stream().anyMatch(r -> r.getNome().equals("CLIENTE"));

        if (isCliente) {
            // Se o usuário logado é um cliente, associa ele automaticamente
            novaVenda.setCliente(usuarioLogado);
        } else {
            // Se for funcionário ou admin, usa o cliente que foi selecionado no dropdown
            novaVenda.setCliente(clienteSelecionado);
        }
        // --- FIM DA LÓGICA ---

        novaVenda = vendaService.salvar(novaVenda);

        carrinho.clear();
        clienteSelecionado = null;
        formaPagamentoSelecionada = "Cartão de Crédito";
        recalcularTotal();
        produtosDisponiveis = produtoService.listarTodos();
        createBarModel();

        FacesContext.getCurrentInstance().getExternalContext().getFlash().setKeepMessages(true);
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Venda #" + novaVenda.getId() + " realizada com sucesso!", null));
        return "recibo.xhtml?faces-redirect=true&vendaId=" + novaVenda.getId();
    }

    // Getters e Setters
    public List<Produto> getProdutosDisponiveis() { return produtosDisponiveis; }
    public List<ItemVenda> getCarrinho() { return carrinho; }
    public BigDecimal getValorTotalCarrinho() { return valorTotalCarrinho; }
    public BarChartModel getBarModel() { return barModel; }
    public List<User> getClientes() { return clientes; }
    public User getClienteSelecionado() { return clienteSelecionado; }
    public void setClienteSelecionado(User clienteSelecionado) { this.clienteSelecionado = clienteSelecionado; }
    public String getFormaPagamentoSelecionada() { return formaPagamentoSelecionada; }
    public void setFormaPagamentoSelecionada(String formaPagamentoSelecionada) { this.formaPagamentoSelecionada = formaPagamentoSelecionada; }
}