package com.av1.projeto.service.categoria;

import com.av1.projeto.model.Categoria;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class CategoriaServiceImpl implements CategoriaService {

    @PersistenceContext
    private EntityManager em;

    @Override
    public Categoria salvar(Categoria categoria) {
        if (categoria.getId() == null) {
            em.persist(categoria);
            return categoria;
        } else {
            return em.merge(categoria);
        }
    }

    @Override
    public List<Categoria> listarTodos() {
        return em.createQuery("SELECT c FROM Categoria c ORDER BY c.nome", Categoria.class).getResultList();
    }

    @Override
    public void remover(Long id) {
        Categoria categoria = em.find(Categoria.class, id);
        if (categoria != null) {
            em.remove(categoria);
        }
    }
}