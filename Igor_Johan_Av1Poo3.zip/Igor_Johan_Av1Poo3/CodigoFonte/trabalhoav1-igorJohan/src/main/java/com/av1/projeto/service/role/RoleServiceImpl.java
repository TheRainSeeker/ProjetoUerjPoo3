package com.av1.projeto.service.role;

import com.av1.projeto.model.Role;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import java.util.List;

@Stateless
public class RoleServiceImpl implements RoleService {

    @PersistenceContext
    private EntityManager em;

    @Override
    public Role findByNome(String nome) {
        try {
            return em.createQuery("SELECT r FROM Role r WHERE r.nome = :nome", Role.class)
                    .setParameter("nome", nome)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        }
    }

    @Override
    public Role salvar(Role role) {
        em.persist(role);
        return role;
    }

    @Override
    public List<Role> listarTodos() {
        return em.createQuery("SELECT r FROM Role r ORDER BY r.nome", Role.class).getResultList();
    }
}