package com.av1.projeto.service.produto;

import com.av1.projeto.model.Produto;
import java.util.List;

public interface ProdutoService {
    Produto salvar(Produto produto);
    List<Produto> listarTodos();
    void remover(Long id);
}